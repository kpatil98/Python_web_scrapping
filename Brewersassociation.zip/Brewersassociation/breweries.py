import requests
import  json
import pandas as pd




present_data_path='D:\\Assignments\\Brewersassociation\\' + str(
        'brewersassociation_site_data_' + '.xlsx')
headers = {
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    # 'cookie': 'OptanonAlertBoxClosed=2024-05-26T18:30:51.816Z; _gcl_au=1.1.1617594496.1716748252; _gid=GA1.2.826268930.1716748253; _fbp=fb.1.1716748253262.881376193; wp_gdbbx_session_activity=0; wp_gdbbx_tracking_activity=1716787860; wp_gdbbx_online_activity=4385-1716787860-8933; OptanonConsent=isGpcEnabled=0&datestamp=Mon+May+27+2024+16%3A59%3A58+GMT%2B0530+(India+Standard+Time)&version=202403.1.0&browserGpcFlag=0&isIABGlobal=false&hosts=&landingPath=NotLandingPage&groups=C0003%3A1%2CC0004%3A1%2CC0002%3A1%2CC0001%3A1&AwaitingReconsent=false&geolocation=SE%3BAB; _gat=1; _ga=GA1.1.440822861.1716748253; _ga_6E0M01V332=GS1.1.1716809403.1.0.1716809415.48.0.0',
    'pragma': 'no-cache',
    'priority': 'u=1, i',
    # 'referer': 'https://www.brewersassociation.org/directories/breweries/',
    'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

params = {
    'nocache': '1716809417394',
}
proxy={'http':"http://sachin:wonHB2023@tampa.wonderproxy.com:11000",
       'https':"http://sachin:wonHB2023@tampa.wonderproxy.com:11000"
               }
response = requests.get(
    'https://www.brewersassociation.org/wp-content/themes/ba2019/json-store/breweries/breweries.json',
    params=params,
    # cookies=cookies,
    proxies=proxy,
    headers=headers,
)
print(response)

if response.status_code == 200:

    jdata = json.loads(response.text)
    data_list=[]

    for item in jdata:
        try:
            id = item['Id']
        except:
            id=''
        try:
            name = item['Name']
        except:
            name=''
        try:
            phone = item['Phone']
        except:
            phone=''

        data_list.append(id)
        data_list.append(name)
        data_list.append(phone)

        try:
            st1 = item['BillingAddress']['street']
            if st1 == Null:
                st1=''
        except:
            st1=''

        try:
            state = item['BillingAddress']['state']
            if state == Null:
                state=''
        except:
            state=''

        try:
            stateCode = item['BillingAddress']['stateCode']
            if stateCode == Null:
                stateCode=''
        except:
            stateCode=''

        try:
            postalCode = item['BillingAddress']['postalCode']
            if postalCode == Null:
                postalCode=''
        except:
            postalCode=''


        if st1 !='' and state != '' and stateCode != '' and postalCode !='':
            address= st1 + ' ' + state + ',' + stateCode +' ' + postalCode
        else:
            address='Not available in required format'

        data_list.append(address)


        print(data_list)

        data_dict={}

        data_dict["Name"]= data_list[1]
        data_dict["ID"]=data_list[0]
        data_dict["Phone"]=data_list[2]
        data_dict["Address"]=data_list[3]

        if len(data_list) > 0:
            df = pd.DataFrame(data_list)
            excel_file = present_data_path
            df.to_excel(excel_file, index=False)
            print("Data added in File Successfully !!")
        else:
            print("No record in File ...")