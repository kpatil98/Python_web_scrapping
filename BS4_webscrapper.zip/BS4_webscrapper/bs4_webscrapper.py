from bs4 import BeautifulSoup
import requests
import openpyxl
import pandas as pd

# Create a new workbook and select the active worksheet
excel = openpyxl.Workbook()
sheet = excel.active
sheet.title = 'Top rated movies'
sheet.append(['Product Name', 'Price', 'Rating'])

def get_data(main_soup):
    data = []
    for item in main_soup:
        prod_name = item.find("a", class_="title").text
        price = item.find("h4", class_="price float-end card-title pull-right").text
        rating = item.find("p", {"data-rating": True})["data-rating"]
        data.append([prod_name, price, rating])
        sheet.append([prod_name, price, rating])
    return data

def get_main_soup(url, index):
    final_url = f"{url}?page={index+1}"
    source = requests.get(final_url)
    soup = BeautifulSoup(source.text, 'html.parser')
    main_soup = soup.find_all('div', class_="product-wrapper card-body")
    return main_soup

try:
    base_url = 'https://webscraper.io/test-sites/e-commerce/static/computers/tablets'
    source = requests.get(base_url)
    print(source.status_code)

    soup = BeautifulSoup(source.text, 'html.parser')
    page_count_soup = soup.find('ul', class_="pagination")
    page_child = page_count_soup.findChildren()

    out_data = []
    if len(page_child) > 2:
        for i in range(len(page_child) - 2):
            main_soup = get_main_soup(base_url, i)
            out_data.extend(get_data(main_soup))

except Exception as e:
    print("Got exception:", e)

# Save the workbook
excel.save('bs4_webscrapper_data.xlsx')
